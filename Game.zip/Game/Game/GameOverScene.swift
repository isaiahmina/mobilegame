//
//  GameOverScene.swift
//  Game
//
//  Created by isaiah on 3/28/19.
//  Copyright © 2019 isaiah. All rights reserved.
//

import SpriteKit

class GameOverScene: SKScene{
    init(size: CGSize, won:Bool){
        super.init(size: size)
        
        backgroundColor = SKColor.white
     
        let message = "The Kingdom has Fallen..."
        let message2 = "Game Over"
        
        let label = SKLabelNode(fontNamed: "")
        let label2 = SKLabelNode(fontNamed: "")
        label.text = message
        label2.text = message2
        label.fontSize = 20
        label2.fontSize = 40
        label.fontColor = SKColor.red
        label2.fontColor = SKColor.red
        label.position = CGPoint(x:size.width/2, y: size.height/2)
        label2.position = CGPoint(x:size.width/2, y: size.height*0.4)
        addChild(label)
        addChild(label2)
        
        run(SKAction.sequence([
            SKAction.wait(forDuration:3.0),
            SKAction.run(){ [weak self] in
              guard let `self` = self else {return}
              let reveal = SKTransition.fade(withDuration: 2)
              let scene = GameScene(size:size)
              self.view?.presentScene(scene,transition:reveal)
            }
            ]))
    }
    required init(coder aDecoder: NSCoder){
        fatalError("init(coder:) has not been implemented")
    }
}
