//
//  GameScene.swift
//  Game
//
//  Created by isaiah on 3/28/19.
//  Copyright © 2019 isaiah. All rights reserved.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene {
    
    var entities = [GKEntity]()
    var graphs = [String : GKGraph]()
    var leftButton = SKNode()
    var rightButton = SKNode()
    var isTouching = false
    private var lastUpdateTime : TimeInterval = 0
    
    let player = SKSpriteNode (imageNamed: "archer")
    //an "array" used to transfer touch points from touchBegan/Ended to the update method
    var touchpoints = Set<UITouch>()
    //variable to set the movement(displacement) speed during button press
    var movespeed = CGFloat(2.5)
    
    
    
    //called after scene is initialized
    override func sceneDidLoad() {
        
    }
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
        
        // Initialize _lastUpdateTime if it has not already been
        if (self.lastUpdateTime == 0) {
            self.lastUpdateTime = currentTime
        }
        
        // Calculate time since last update
        let dt = currentTime - self.lastUpdateTime
        
        // Update entities
        for entity in self.entities {
            entity.update(deltaTime: dt)
        }
        
        self.lastUpdateTime = currentTime
        
        
        /************button stuff**************/
        //the code below is used in conjunction with touchesBegan/Ended to
        //implement function execution while a button is held
        if(isTouching){
            //loop over all touches in this event
            for touch: AnyObject in touchpoints {
                //get location of the touch
                let location = touch.location(in: self)
                
                //if push left button move left
                if leftButton.contains(location){
                    //keep player from moving offscreen
                    if(player.position.x <= player.size.width/2){
                        return
                    }else{
                    player.position = CGPoint(x:player.position.x-movespeed,y:player.position.y)
                    }
                }
                //if push right button move right
                if rightButton.contains(location){
                    //keep player from moving offscreen
                    if(player.position.x >= size.width - player.size.width/2){
                        return
                    }else{
                    player.position = CGPoint(x:player.position.x+movespeed,y:player.position.y)
                    }
                }
                //if(push shoot){shoot function that has ~1sec delay}
            }
        }
    }
    
    
    
    //called after scene is presented to view
    override func didMove(to view: SKView){
        backgroundColor = SKColor.green
        player.position = CGPoint(x:size.width * 0.5, y: size.height * 0.2)
        player.zPosition=1
        addChild(player)
        
        /* let background = SKSpriteNode(imageNamed: "imagenamehere")
         background.position = CGPoint(x: size.width/2, y: size.height/2)
         background.zPosition=-1
         //anchor point is center screen; 1.0,1.0 is top right corner, 0,0 is bottom left
         background.anchorPoint = CGPoint(x: 0.5, y: 0.5)
         */
        
        //create move buttons
        leftButton = SKSpriteNode(imageNamed: "leftbutton")
        rightButton = SKSpriteNode(imageNamed: "rightbutton")
        //position them in the scene
        leftButton.position = CGPoint(x: 70, y:60)
        rightButton.position = CGPoint(x: 180, y:60)
        addChild(leftButton)
        addChild(rightButton)

        //add enemies indefinately
        run(SKAction.repeatForever(
            SKAction.sequence([
                SKAction.run(addEnemy),SKAction.wait(forDuration: 2.0)
                ])
        ))
    }
    
    //set bool to true if touches detected (used in conjunction with code in the update
    //function in order to implement code execution while button is being held down
     override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        isTouching = true;
        touchpoints=touches
    }//and to false if touches end
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        isTouching = false;
        touchpoints = touches
    }
    
    //random number function
    func random() -> CGFloat {
        return CGFloat(Float(arc4random()) / 0xFFFFFFFF)
    }
    //random number overload
    func random(min: CGFloat, max: CGFloat) -> CGFloat{
        return random() * (max-min) + min
    }
    
    func addEnemy(){
        let enemy = SKSpriteNode(imageNamed:"enemy")
        //decide the Horizontal location of the enemy: min=half enemy size to avoid spawning half-off-screen; same for max
        let actualX = random(min: enemy.size.width/2, max: size.width - enemy.size.width/2)
        //spawn slightly off top of screen
        enemy.position = CGPoint(x:actualX,y:size.height+enemy.size.width/2)
        enemy.zPosition = 1
        addChild(enemy)
        
        let actualDuration = random(min: CGFloat(4.0), max: CGFloat(10.0))
        //move to opposite side of map over (actualDruation) seconds
        let actionMove = SKAction.move(to:CGPoint(x: actualX, y: -enemy.size.height/2), duration:TimeInterval(actualDuration))
        //delete enemy after reached destination
        let actionMoveDone = SKAction.removeFromParent()
        enemy.run(SKAction.sequence([actionMove,actionMoveDone]))
    }
    
    
}

