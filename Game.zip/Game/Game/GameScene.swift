//
//  GameScene.swift
//  Game
//
//  Created by isaiah on 3/28/19.
//  Copyright © 2019 isaiah. All rights reserved.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene {
    
    var entities = [GKEntity]()
    var graphs = [String : GKGraph]()
    var leftButton = SKNode()
    var rightButton = SKNode()
    var shootButton = SKNode()
    var pauseButton = SKNode()
    var unpauseButton = SKSpriteNode()
    var hp1 = SKNode()
    var hp2 = SKNode()
    var hp3 = SKNode()
    var pauseNode = SKNode()    //used to pause entities
    var enemyLabel = SKLabelNode()
    var pausedLabel = SKLabelNode()
    var health = 3;
    var enemydefeated = 0;
    var isTouching = false
    var gamePaused = false
    private var lastUpdateTime : TimeInterval = 0
    
    let player = SKSpriteNode (imageNamed: "archer")
    //an "array" used to transfer touch points from touchBegan/Ended to the update method
    var touchpoints = Set<UITouch>()
    //variable to set the movement(displacement) speed during button press
    var movespeed = CGFloat(2.5)
    
    //setup for physics world
    struct PhysicsCategory{
        static let none  : UInt32 = 0
        static let all   : UInt32 = UInt32.max
        static let enemy : UInt32 = 0b1     //bitmask for enemy entities
        static let arrow : UInt32 = 0b10    //bitmask for arrow projectiles
    }
    
    //called after scene is initialized
    override func sceneDidLoad() {
        
    }
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
        
        // Initialize _lastUpdateTime if it has not already been
        if (self.lastUpdateTime == 0) {
            self.lastUpdateTime = currentTime
        }
        
        // Calculate time since last update
        let dt = currentTime - self.lastUpdateTime
        
        // Update entities
        for entity in self.entities {
            entity.update(deltaTime: dt)
        }
        
        self.lastUpdateTime = currentTime
        
        //update kill count
        let strenemydefeated = "Kills: " + String(enemydefeated)
        enemyLabel.text = strenemydefeated
        
        // lose screen transition
        if(health == 0 ){
            let loseAction = SKAction.run(){ [weak self] in
                guard let `self` = self else {return}
                let reveal = SKTransition.fade(withDuration: 2)
                let gameOverScene = GameOverScene(size: self.size, won: false)
                self.view?.presentScene(gameOverScene, transition: reveal)
            }
            self.run(SKAction.sequence([loseAction]))
        }
        
        /************button stuff**************/
        //the code below is used in conjunction with touchesBegan/Ended to
        //implement function execution while a button is held
        
        //don't move player if paused
        if(gamePaused==true){
            return
        }
        
        if(isTouching){
            //loop over all touches in this event
            for touch: AnyObject in touchpoints {
                //get location of the touch
                let location = touch.location(in: self)
                
                //if push left button move left
                if leftButton.contains(location){
                    //keep player from moving offscreen
                    if(player.position.x <= player.size.width/2){
                        return
                    }else{
                    player.position = CGPoint(x:player.position.x-movespeed,y:player.position.y)
                    }
                }
                //if push right button move right
                if rightButton.contains(location){
                    //keep player from moving offscreen
                    if(player.position.x >= size.width - player.size.width/2){
                        return
                    }else{
                    player.position = CGPoint(x:player.position.x +
                        movespeed,y:player.position.y)
                    }
                }
                //shooting is handled in touchesBegan to implement 1 arrow per touch
                //(otherwise we'd have a laserbeam of arrows if it were here)
            }
        
        }
        
        
    }
    
    //called after scene is presented to view
    override func didMove(to view: SKView){
        //add the node used to control pausing entities
        addChild(pauseNode)
        
        //backgroundColor = SKColor.green
        player.position = CGPoint(x:size.width * 0.5, y: size.height * 0.3)
        player.zPosition=1
        //we want player to be pause-able so add it to the pause node
        pauseNode.addChild(player)
        
        physicsWorld.gravity = .zero
        physicsWorld.contactDelegate = self
        
        //create background
        let background = SKSpriteNode(imageNamed: "background")
        background.position = CGPoint(x: size.width/2, y: size.height/2)
        background.zPosition = -1
        //size it to match the screen
        background.size = UIScreen.main.bounds.size
        //anchor point is center screen; 1.0,1.0 is top right corner, 0,0 is bottom left
        background.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        addChild(background)
        
        
        //create move buttons
        leftButton = SKSpriteNode(imageNamed: "leftbutton")
        rightButton = SKSpriteNode(imageNamed: "rightbutton")
        shootButton = SKSpriteNode(imageNamed: "shoot")
        //position them in the scene
        leftButton.position = CGPoint(x: size.width*0.2, y:60)
        rightButton.position = CGPoint(x: size.width*0.45, y:60)
        shootButton.position = CGPoint(x: size.width*0.8, y:60)
        addChild(leftButton)
        addChild(rightButton)
        addChild(shootButton)
        
        //create health hearts
        hp1 = SKSpriteNode(imageNamed: "Heart")
        hp2 = SKSpriteNode(imageNamed: "Heart")
        hp3 = SKSpriteNode(imageNamed: "Heart")
        hp1.position = CGPoint(x:size.width*0.4, y:size.height*0.2)
        hp2.position = CGPoint(x:size.width*0.5, y:size.height*0.2)
        hp3.position = CGPoint(x:size.width*0.6, y:size.height*0.2)
        addChild(hp1)
        addChild(hp2)
        addChild(hp3)
        
        //create enemy defeated counter
        enemyLabel.position = CGPoint(x: size.width*0.2, y:size.height*0.9)
        enemyLabel.fontName = "chalkduster"
        enemyLabel.fontSize = 24
        enemyLabel.fontColor = UIColor.red
        addChild(enemyLabel)
        
        //create pause button
        pauseButton = SKSpriteNode(imageNamed: "Pause")
        pauseButton.position = CGPoint(x:size.width*0.9, y:size.height*0.9)
        addChild(pauseButton)

        //add enemies indefinately
        run(SKAction.repeatForever(
            SKAction.sequence([
                SKAction.run(addEnemy),SKAction.wait(forDuration: 2.0)
                ])
        ))
    }
    
    //set bool to true if touches detected (used in conjunction with code in the update
    //function in order to implement code execution while button is being held down
     override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        isTouching = true;
        touchpoints=touches
        
        //get the first registered touch and store it's touch location
        guard let touch = touches.first else { return }
        let location = touch.location(in: self)
        
        //pause and unpause
        if pauseButton.contains(location){
            pauseGame()
        }
        if(unpauseButton.contains(location)){
            playGame()
            
        }
        
        //if push shoot, then shoot
            //don't create arrows when shoot button is tapped while paused
            if(gamePaused==true){
                return
            }
        else if shootButton.contains(location){
            let arrow = SKSpriteNode(imageNamed:"arrow")
            arrow.position = player.position
            pauseNode.addChild(arrow)
            
            //arrow physics stuff
            arrow.physicsBody = SKPhysicsBody(rectangleOf: arrow.size)
            arrow.physicsBody?.isDynamic = true
                //what bitmask is it?
            arrow.physicsBody?.categoryBitMask = PhysicsCategory.arrow
                //what bitmask should it notify upon collision?
            arrow.physicsBody?.contactTestBitMask = PhysicsCategory.enemy
                //what does it bounce off?
            arrow.physicsBody?.collisionBitMask = PhysicsCategory.none
            arrow.physicsBody?.usesPreciseCollisionDetection = true     //so it doesn't phase through
            
            let actionMove = SKAction.move(to: CGPoint(x:player.position.x,y:player.position.y+1000), duration:4.0)
            let actionMoveDone = SKAction.removeFromParent()
            //fire arrow, remove arrow after done traveling
            arrow.run(SKAction.sequence([actionMove, actionMoveDone]))
        }
        
        
    }//and change 'isTouching' boolean to false when touching is done
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        isTouching = false;
        touchpoints = touches
    }
    
    //random number function
    func random() -> CGFloat {
        return CGFloat(Float(arc4random()) / 0xFFFFFFFF)
    }
    //random number overload
    func random(min: CGFloat, max: CGFloat) -> CGFloat{
        return random() * (max-min) + min
    }
    
    func addEnemy(){
        //don't spawn enemies while game is paused
        if(gamePaused==true){
            return
        }
        let enemy = SKSpriteNode(imageNamed:"enemy")
        //decide the Horizontal location of the enemy: min=half enemy size to avoid spawning half-off-screen; same for max
        let actualX = random(min: enemy.size.width/2, max: size.width - enemy.size.width/2)
        //spawn slightly off top of screen
        enemy.position = CGPoint(x:actualX,y:size.height+enemy.size.width/2)
        enemy.zPosition = 1
        //addChild(enemy)
        pauseNode.addChild(enemy)
        
        //enemy physics bitmasks
        enemy.physicsBody = SKPhysicsBody(rectangleOf: enemy.size)
        enemy.physicsBody?.isDynamic = true
        enemy.physicsBody?.categoryBitMask = PhysicsCategory.enemy      //what bitmask is it?
        enemy.physicsBody?.contactTestBitMask = PhysicsCategory.arrow   //what bitmask should it notify on collision?
        enemy.physicsBody?.collisionBitMask = PhysicsCategory.none      //what does it bounce off?
        
        
        let actualDuration = random(min: CGFloat(3.0), max: CGFloat(6.0))
        //move to the wall over (actualDruation) seconds
        let actionMove = SKAction.move(to:CGPoint(x: actualX, y: size.height*0.25), duration:TimeInterval(actualDuration))
        //delete enemy after reached destination
        let actionMoveDone = SKAction.removeFromParent()
        let actionDamage = SKAction.run{
            if(self.health==3){self.hp3.removeFromParent(); self.health-=1}
            else if (self.health==2){self.hp2.removeFromParent();self.health-=1}
            else if (self.health==1){self.hp1.removeFromParent();self.health-=1}
        }
        enemy.run(SKAction.sequence([actionMove,actionDamage,actionMoveDone]))
    }
    
    func projectileCollideWithEnemy(arrow: SKSpriteNode, enemy: SKSpriteNode){
        arrow.removeFromParent()
        enemy.removeFromParent()
        enemydefeated+=1
    }
}

    //physics stuff for detecting what contacted what and to call the removal method
    extension GameScene: SKPhysicsContactDelegate{
        func didBegin(_ contact: SKPhysicsContact) {
            var firstObj: SKPhysicsBody
            var secondObj: SKPhysicsBody
            //re-arrange so that enemy is always first object, arrow is always second object)
            if contact.bodyA.categoryBitMask < contact.bodyB.categoryBitMask{
                firstObj = contact.bodyA
                secondObj = contact.bodyB
            }else{
                firstObj = contact.bodyB
                secondObj = contact.bodyA
            }
            //if first object is an enemy and second object is an arrow, call the method to delete the sprites
            if((firstObj.categoryBitMask & PhysicsCategory.enemy != 0) && (secondObj.categoryBitMask & PhysicsCategory.arrow != 0)){
                if let enemy = firstObj.node as? SKSpriteNode, let arrow = secondObj.node as? SKSpriteNode{
                    projectileCollideWithEnemy(arrow: arrow, enemy: enemy)
                }
            }
        }
        
        func pauseGame(){
            //pause the pauseNode, and all children
            gamePaused=true
            pauseNode.isPaused=true
            physicsWorld.speed = 0
            
            //create the "pause screen"
            pausedLabel = SKLabelNode()
            pausedLabel.text = "Game Paused"
            pausedLabel.fontName = "Chalkduster"
            pausedLabel.fontSize = 40
            pausedLabel.fontColor = UIColor.black
            pausedLabel.position = CGPoint(x:size.width*0.5, y:size.height*0.6)
            addChild(pausedLabel)
            
            unpauseButton = SKSpriteNode(imageNamed: "Play")
            unpauseButton.position = CGPoint(x:size.width*0.5, y:size.height*0.5)
            addChild(unpauseButton)
        }
        func playGame(){
            //unpause pause node
            gamePaused=false
            pauseNode.isPaused=false
            physicsWorld.speed = 1
            
            //remove the pause screen
            pausedLabel.removeFromParent()
            unpauseButton.removeFromParent()
            
        }
    }

    


