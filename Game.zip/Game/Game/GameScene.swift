//
//  GameScene.swift
//  Game
//
//  Created by isaiah on 3/28/19.
//  Copyright © 2019 isaiah. All rights reserved.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene {
    
    var entities = [GKEntity]()
    var graphs = [String : GKGraph]()
    var leftButton = SKNode()
    var rightButton = SKNode()
    var shootButton = SKNode()
    var hp1 = SKNode()
    var hp2 = SKNode()
    var hp3 = SKNode()
    var enemyLabel = SKLabelNode()
    var health = 3;
    var enemydefeated = 0;
    var isTouching = false
    private var lastUpdateTime : TimeInterval = 0
    
    let player = SKSpriteNode (imageNamed: "archer")
    //an "array" used to transfer touch points from touchBegan/Ended to the update method
    var touchpoints = Set<UITouch>()
    //variable to set the movement(displacement) speed during button press
    var movespeed = CGFloat(2.5)
    
    //setup for physics world
    struct PhysicsCategory{
        static let none  : UInt32 = 0
        static let all   : UInt32 = UInt32.max
        static let enemy : UInt32 = 0b1
        static let arrow : UInt32 = 0b10
    }
    
    //called after scene is initialized
    override func sceneDidLoad() {
        
    }
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
        
        // Initialize _lastUpdateTime if it has not already been
        if (self.lastUpdateTime == 0) {
            self.lastUpdateTime = currentTime
        }
        
        // Calculate time since last update
        let dt = currentTime - self.lastUpdateTime
        
        // Update entities
        for entity in self.entities {
            entity.update(deltaTime: dt)
        }
        
        self.lastUpdateTime = currentTime
        
        //update kill count
        var strenemydefeated = "Kills: " + String(enemydefeated)
        enemyLabel.text = strenemydefeated
        
        /************button stuff**************/
        //the code below is used in conjunction with touchesBegan/Ended to
        //implement function execution while a button is held
        if(isTouching){
            //loop over all touches in this event
            for touch: AnyObject in touchpoints {
                //get location of the touch
                let location = touch.location(in: self)
                
                //if push left button move left
                if leftButton.contains(location){
                    //keep player from moving offscreen
                    if(player.position.x <= player.size.width/2){
                        return
                    }else{
                    player.position = CGPoint(x:player.position.x-movespeed,y:player.position.y)
                    }
                }
                //if push right button move right
                if rightButton.contains(location){
                    //keep player from moving offscreen
                    if(player.position.x >= size.width - player.size.width/2){
                        return
                    }else{
                    player.position = CGPoint(x:player.position.x+movespeed,y:player.position.y)
                    }
                }
                //shooting is handled in touchesBegan to implement 1 arrow per touch
                //(otherwise we'd have a laserbeam of arrows if it were here)
                
            }
        
        }
        
        // lose screen transition
        if(health == 0 ){
            let loseAction = SKAction.run(){ [weak self] in
                guard let `self` = self else {return}
                let reveal = SKTransition.fade(withDuration: 2)
                let gameOverScene = GameOverScene(size: self.size, won: false)
                self.view?.presentScene(gameOverScene, transition: reveal)
            }
            self.run(SKAction.sequence([loseAction]))
        }
    }
    
    //called after scene is presented to view
    override func didMove(to view: SKView){
        backgroundColor = SKColor.green
        player.position = CGPoint(x:size.width * 0.5, y: size.height * 0.3)
        player.zPosition=1
        addChild(player)
        physicsWorld.gravity = .zero
        physicsWorld.contactDelegate = self
        
        /* let background = SKSpriteNode(imageNamed: "imagenamehere")
         background.position = CGPoint(x: size.width/2, y: size.height/2)
         background.zPosition=-1
         //anchor point is center screen; 1.0,1.0 is top right corner, 0,0 is bottom left
         background.anchorPoint = CGPoint(x: 0.5, y: 0.5)
         */
        
        //create move buttons
        leftButton = SKSpriteNode(imageNamed: "leftbutton")
        rightButton = SKSpriteNode(imageNamed: "rightbutton")
        shootButton = SKSpriteNode(imageNamed: "shoot")
        //position them in the scene
        leftButton.position = CGPoint(x: size.width*0.2, y:60)
        rightButton.position = CGPoint(x: size.width*0.45, y:60)
        shootButton.position = CGPoint(x: size.width*0.8, y:60)
        addChild(leftButton)
        addChild(rightButton)
        addChild(shootButton)
        
        //create health hearts
        hp1 = SKSpriteNode(imageNamed: "Heart")
        hp2 = SKSpriteNode(imageNamed: "Heart")
        hp3 = SKSpriteNode(imageNamed: "Heart")
        hp1.position = CGPoint(x:size.width*0.4, y:size.height*0.2)
        hp2.position = CGPoint(x:size.width*0.5, y:size.height*0.2)
        hp3.position = CGPoint(x:size.width*0.6, y:size.height*0.2)
        addChild(hp1)
        addChild(hp2)
        addChild(hp3)
        
        //create enemy defeated counter
        enemyLabel.position = CGPoint(x: size.width*0.15, y:size.height*0.85)
        enemyLabel.fontSize = 10
        enemyLabel.fontColor = UIColor.red
        addChild(enemyLabel)
        

        //add enemies indefinately
        run(SKAction.repeatForever(
            SKAction.sequence([
                SKAction.run(addEnemy),SKAction.wait(forDuration: 2.0)
                ])
        ))
    }
    
    //set bool to true if touches detected (used in conjunction with code in the update
    //function in order to implement code execution while button is being held down
     override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        isTouching = true;
        touchpoints=touches
        
        guard let touch = touches.first else { return }
        let location = touch.location(in: self)
        
        //if push shoot, then shoot
        if shootButton.contains(location){
            let arrow = SKSpriteNode(imageNamed:"arrow")
            arrow.position = player.position
            addChild(arrow)
            
            //arrow physics stuff
            arrow.physicsBody = SKPhysicsBody(rectangleOf: arrow.size)
            arrow.physicsBody?.isDynamic = true
            arrow.physicsBody?.categoryBitMask = PhysicsCategory.arrow
            arrow.physicsBody?.contactTestBitMask = PhysicsCategory.enemy
            arrow.physicsBody?.collisionBitMask = PhysicsCategory.none
            arrow.physicsBody?.usesPreciseCollisionDetection = true     //so it doesn't phase through
            
            let actionMove = SKAction.move(to: CGPoint(x:player.position.x,y:player.position.y+1000), duration:4.0)
            let actionMoveDone = SKAction.removeFromParent()
            //fire arrow, remove arrow after done traveling
            arrow.run(SKAction.sequence([actionMove, actionMoveDone]))
        }
    }//and to false if touches end
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        isTouching = false;
        touchpoints = touches
    }
    
    //random number function
    func random() -> CGFloat {
        return CGFloat(Float(arc4random()) / 0xFFFFFFFF)
    }
    //random number overload
    func random(min: CGFloat, max: CGFloat) -> CGFloat{
        return random() * (max-min) + min
    }
    
    func addEnemy(){
        let enemy = SKSpriteNode(imageNamed:"enemy")
        //decide the Horizontal location of the enemy: min=half enemy size to avoid spawning half-off-screen; same for max
        let actualX = random(min: enemy.size.width/2, max: size.width - enemy.size.width/2)
        //spawn slightly off top of screen
        enemy.position = CGPoint(x:actualX,y:size.height+enemy.size.width/2)
        enemy.zPosition = 1
        addChild(enemy)
        
        //enemy physics bitmasks
        enemy.physicsBody = SKPhysicsBody(rectangleOf: enemy.size)
        enemy.physicsBody?.isDynamic = true
        enemy.physicsBody?.categoryBitMask = PhysicsCategory.enemy      //what bitmask is it?
        enemy.physicsBody?.contactTestBitMask = PhysicsCategory.arrow   //what bitmask should it notify on collision?
        enemy.physicsBody?.collisionBitMask = PhysicsCategory.none      //what does it bounce off?
        
        
        let actualDuration = random(min: CGFloat(3.0), max: CGFloat(6.0))
        //move to opposite side of map over (actualDruation) seconds
        let actionMove = SKAction.move(to:CGPoint(x: actualX, y: size.height*0.25), duration:TimeInterval(actualDuration))
        //delete enemy after reached destination
        let actionMoveDone = SKAction.removeFromParent()
        let actionDamage = SKAction.run{
            if(self.health==3){self.hp3.removeFromParent(); self.health-=1}
            else if (self.health==2){self.hp2.removeFromParent();self.health-=1}
            else if (self.health==1){self.hp1.removeFromParent();self.health-=1}
        }
        enemy.run(SKAction.sequence([actionMove,actionDamage,actionMoveDone]))
    }
    
    func projectileCollideWithEnemy(arrow: SKSpriteNode, enemy: SKSpriteNode){
        arrow.removeFromParent()
        enemy.removeFromParent()
        enemydefeated+=1
    }
}

    //physics stuff for detecting what contacted what and to call the removal method
    extension GameScene: SKPhysicsContactDelegate{
        func didBegin(_ contact: SKPhysicsContact) {
            var firstObj: SKPhysicsBody
            var secondObj: SKPhysicsBody
            //re-arrange so that enemy is always first object, arrow is always second object)
            if contact.bodyA.categoryBitMask < contact.bodyB.categoryBitMask{
                firstObj = contact.bodyA
                secondObj = contact.bodyB
            }else{
                firstObj = contact.bodyB
                secondObj = contact.bodyA
            }
            //if first object is an enemy and second object is an arrow, call the method to delete the sprites
            if((firstObj.categoryBitMask & PhysicsCategory.enemy != 0) && (secondObj.categoryBitMask & PhysicsCategory.arrow != 0)){
                if let enemy = firstObj.node as? SKSpriteNode, let arrow = secondObj.node as? SKSpriteNode{
                    projectileCollideWithEnemy(arrow: arrow, enemy: enemy)
                }
            }
        }
    }
    


