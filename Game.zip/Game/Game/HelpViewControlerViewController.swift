//
//  HelpViewControlerViewController.swift
//  Game
//
//  Created by Isaiah on 4/18/19.
//  Copyright © 2019 isaiah. All rights reserved.
//

import UIKit

class HelpViewControlerViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }

    @IBAction func close(){
        dismiss(animated: true, completion: nil)
    }
}
